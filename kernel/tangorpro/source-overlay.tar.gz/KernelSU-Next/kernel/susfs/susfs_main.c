// SPDX-License-Identifier: GPL-2.0
/*
 * susfs_main.c - SUSFS LKM entry point: the layer table plus this module's control nodes.
 * Loaded via `ksud insmod`, with unexported symbols relocated via kallsyms.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/version.h>	/* LINUX_VERSION_CODE: the MODULE_IMPORT_NS spelling below */
#include <linux/fs.h>		/* d_inode() for the control-node labels */
#include <linux/security.h>	/* security_secctx_to_secid(): the nodes' SELinux label */

#include "symbol_resolver.h"
#include "ksu_allow_gate.h"	/* susfs_ksu_allow_kind: whether ksu_file applies at all */
#include "patch_memory.h"	/* ksu_patch_memory_init(): the flush helper's name differs per kernel */
#include "susfs_enable_log.h"
#include "susfs_log.h"
#include "ksu_umount_gate.h"
#include "ksu_allow_gate.h"	/* KernelSU's allow predicate: the control-node gate */
#include "btf_layout.h"		/* the SELinux inode_security_struct.sid offset, by BTF */
#include "lsm_hook.h"
#include "spoof_cmdline.h"
#include "sus_map.h"
#include "sus_mount.h"
#include "sus_path.h"
#include "susfs_avc_spoof.h"
#include "susfs_control.h"
#include "susfs_core.h"
#include "susfs_create_gate.h"
#include "susfs_dirent.h"
#include "susfs_hide_syms.h"
#include "susfs_kstat.h"
#include "susfs_open_redirect.h"
#include "susfs_supercall.h"
#include "susfs_uname.h"
#include "susfs_opath.h"	/* SUSFS_OPATH_NODE + the layer's init/exit */
#include "susfs_fp_hook.h"	/* susfs_fp_init: the sys_call_table cache every fp layer installs through */
#include "susfs_hook_map.h"	/* the loader-patched inline capability map */
#include "susfs_hook_engine.h"
#include "susfs_hooks.h"
#include "susfs_main_data.h"

/* The module's own name lives in susfs_core.h (SUSFS_LKM_MODULE_NAME / SUSFS_LKM_SYSFS_DIR):
 * /sys/module's directory and the rules that hide it (susfs_hide_syms.c) must agree, and the
 * version lives there as well (SUSFS_LKM_VERSION) because the load-time guard can refuse the
 * module before this file's banner runs. */

/* The /proc/susfs_* control nodes are created by default and are 0777 on purpose.
 * Measured on device, 0600 plus sus_path hiding does not work: `ls -l /proc/susfs_kstat`
 * -> ENOENT (the inode_getattr hook fired) but `cat` -> Permission denied (it did not), with
 * sus_path's perm counter stuck at 0 - inode_permission() runs the DAC check BEFORE
 * security_inode_permission(), so a 0600 root-owned node fails DAC first, the LSM hook is
 * never reached, and EACCES advertises that the node exists.  General to sus_path's path
 * layer: it can only turn an ENOENT-shaped answer out of files DAC would have ALLOWED.
 * Hence 0777: DAC passes, the LSM layer is the only thing that answers (ENOENT for every
 * non-root caller).
 * The nodes exist only when the layer that hides them is installed
 * (susfs_control_node_allowed()), so an unprotected world-writable node cannot happen, and
 * root-only access is enforced by the handlers' uid checks, not by the mode.  expose_proc=0
 * removes the nodes entirely. */
/* Register our control nodes in sus_path's hidden set: probing them must answer ENOENT,
 * not EACCES.  Runs after every feature init (the nodes must exist for kern_path() to
 * resolve them) and after sus_path_init(), so the hooks are already patched. */
void susfs_self_hide_nodes(void)
{
    int i;

    if (!susfs_expose_proc)
        return;

    for (i = 0; i < susfs_self_hide_paths_count; i++) {
        int rc = sus_path_add_self_hidden(susfs_self_hide_paths[i]);

        if (rc)
            pr_warn("susfs_guard_lkm: self-hide %s failed %d\n",
                    susfs_self_hide_paths[i], rc);
    }
}

extern void susfs_relabel_control_nodes(void);

static int layer_lsm_hook_init(void)
{
    ksu_lsm_hook_init();
    if (!ksu_lsm_hook_ready()) {
        pr_err("lsm_hook: the table hook insertion walks is not resolvable on this kernel - refusing to load\n");
        return -ENOENT;
    }
    return 0;
}

/* Layer ids: the load order indexes susfs_layers[] through these, and susfs_load_plan[] below
 * carries the per-layer FATAL bool passed to susfs_load_layer().  Keep the enum and the table in
 * the same order. */
enum susfs_layer_id {
    SUSFS_L_FP_HOOK = 0,
    SUSFS_L_HOOKS,
    SUSFS_L_KSU_UMOUNT_GATE,
    SUSFS_L_KSU_ALLOW_GATE,
    SUSFS_L_LSM_HOOK,
    SUSFS_L_SUS_PATH,
    SUSFS_L_CREATE_GATE,
    SUSFS_L_OPATH,
    SUSFS_L_DIRENT,
    SUSFS_L_UNAME,
    SUSFS_L_KSTAT,
    SUSFS_L_SUS_MAP,
    SUSFS_L_SUS_MOUNT,
    SUSFS_L_CMDLINE,
    SUSFS_L_OPEN_REDIRECT,
    SUSFS_L_ENABLE_LOG,
    SUSFS_L_AVC_SPOOF,
    SUSFS_L_SUPERCALL,
    SUSFS_L_HIDE_SYMS,
    SUSFS_L_COUNT,
};

/* Not const: the `armed` flags live here (the pointers must outlive __init too). */
static struct susfs_layer {
    const char *name;
    int (*init)(void);
    void (*exit)(void);
    bool armed;			/* exit is run for every layer that was attempted */
    int feature;			/* enum susfs_feature armed on a successful init, or -1 */
} susfs_layers[] = {
    /* First, and FATAL: every fp-hook layer below (create_gate, opath, dirent, kstat, ...)
     * installs its entries through this cache.  A module that loaded without it would accept
     * rules that no fp-hook layer can ever apply - the "loaded but inert" shape this table
     * exists to avoid - so a missing sys_call_table refuses the load.  The init is idempotent
     * (the later layers' own susfs_fp_init() calls are no-ops once the cache is set), and
     * there is no exit: only the pointer is cached, the entries are restored by their owner. */
    { "fp_hook",	susfs_fp_init,			NULL,			false, -1 },
    { "hooks",		susfs_hooks_init,		susfs_hooks_exit,		false, -1 },
    /* NOT fatal: this layer only decides whether KernelSU's predicate was found at load.
     * When it was not, the gates answer the pre-#34 way and every other layer still works - so a
     * failure here is a degradation, not a reason to refuse the module.  Skipping this init entirely
     * (fail_layer=2) is safe for the same reason: the flag it sets defaults to the pre-#34 answer. */
    { "ksu_umount_gate", susfs_ksu_umount_gate_init,	NULL,			false, -1 },
    { "ksu_allow_gate",	susfs_ksu_allow_gate_init,	NULL,			false, -1 },
    /* FATAL: every LSM layer below (sus_path first) inserts through this file's table hooks.
     * A module that loads without it would accept rules no LSM layer can apply - the same
     * "loaded but inert" shape fp_hook is fatal for.  ksu_lsm_hook_init() itself only
     * reports; the refusal lives here, where a failure can fail the load. */
    { "lsm_hook",	layer_lsm_hook_init,		ksu_lsm_hook_exit,	false, -1 },
    { "sus_path",	sus_path_init,			sus_path_exit,		false, SUSFS_FEAT_SUS_PATH },
    /* After sus_path, whose rule table and per-caller gate it asks.  NOT fatal: when it
     * cannot arm, the create family keeps answering the kernel's own way (EEXIST for a
     * hidden name) - the read paths are unaffected. */
    { "create_gate",	susfs_create_gate_init,		susfs_create_gate_exit,	false, SUSFS_FEAT_SUS_PATH },
    /* After sus_path, because this layer asks sus_path's rule table for every open it
     * post-checks - arming it first would install table entries that answer from a table
     * nobody has filled in yet.  NOT fatal: a failure here only means open(..., O_PATH) keeps
     * answering the pre-layer way (which is what the layer exists to fix, not what makes the
     * module useful), and every entry carries its own reason in the log. */
    { "opath",		susfs_opath_init,		susfs_opath_exit,	false, SUSFS_FEAT_SUS_PATH },
    /* After sus_path, whose rule table it asks.  NOT fatal: when it does not arm the
     * post-hoc filter still hides, it is only detectable while doing so. */
    { "dirent",		susfs_sus_dirent_init,		susfs_sus_dirent_exit,	false, SUSFS_FEAT_SUS_PATH },
    { "uname",		susfs_uname_init,		susfs_uname_exit,	false, SUSFS_FEAT_SPOOF_UNAME },
    { "kstat",		susfs_kstat_init,		susfs_kstat_exit,	false, SUSFS_FEAT_SUS_KSTAT },
    { "sus_map",	susfs_sus_map_init,		susfs_sus_map_exit,	false, SUSFS_FEAT_SUS_MAP },
    { "sus_mount",	susfs_sus_mount_init,		susfs_sus_mount_exit,	false, SUSFS_FEAT_SUS_MOUNT },
    { "cmdline",	susfs_spoof_cmdline_init,	susfs_spoof_cmdline_exit, false, SUSFS_FEAT_SPOOF_CMDLINE },
    { "open_redirect",	susfs_open_redirect_init,	susfs_open_redirect_exit, false, SUSFS_FEAT_OPEN_REDIRECT },
    { "enable_log",	susfs_enable_log_init,		susfs_enable_log_exit,	false, SUSFS_FEAT_ENABLE_LOG },
    { "avc_spoof",	susfs_avc_spoof_init,		susfs_avc_spoof_exit,	false, SUSFS_FEAT_AVC_SPOOF },
    { "supercall",	susfs_supercall_init,		susfs_supercall_exit,	false, -1 },
    { "hide_syms",	susfs_hide_syms_init,		susfs_hide_syms_exit,	false, SUSFS_FEAT_HIDE_SYMS },
};

/* Diagnostic: make one layer's init fail, by 1-based index, to exercise the rollback path
 * on the device - a `fatal` layer failing must leave the load with nothing armed.
 * `fail_layer=2` skips the ksu_umount_gate init WITHOUT failing the load (that layer is not fatal),
 * which is safe only because its flag defaults to the pre-#34 answer - see ksu_umount_gate.c.
 *
 * Index map (keep this list and the fail_layer= references in tools/verify-gki.sh and the layer
 * comments in sync whenever a layer is inserted):
 *   1 fp_hook   2 ksu_umount_gate  3 ksu_allow_gate  4 lsm_hook   5 sus_path
 *   6 create_gate  7 opath  8 dirent  9 uname  10 kstat  11 sus_map  12 sus_mount
 *   13 cmdline  14 open_redirect  15 enable_log  16 avc_spoof  17 supercall  18 hide_syms
 */
static int fail_layer;
module_param_named(fail_layer, fail_layer, int, 0644);

/* Not __init/__exit: it is called from both, and an __exit callee in __init code is a
 * modpost section mismatch. */
/* noinline: its indirect calls through susfs_layers[] belong to this allow-listed function;
 * inlined into module_exit they would land in cleanup_module, which the CFI gate does not allow. */
static noinline void susfs_layers_down(int upto)
{
    int i;

    for (i = upto; i >= 0; i--) {
        if (!susfs_layers[i].armed)
            continue;
        susfs_layers[i].armed = false;
        if (susfs_layers[i].exit)
            susfs_layers[i].exit();
    }
}

/* The load order and the fatal decision live here, not in the table: susfs_load_layer()
 * receives the bool and owns the rollback-or-warn policy. */
static const struct {
    int id;
    bool fatal;
} susfs_load_plan[] = {
    { SUSFS_L_FP_HOOK, true },
    { SUSFS_L_HOOKS, false },
    { SUSFS_L_KSU_UMOUNT_GATE, false },
    { SUSFS_L_KSU_ALLOW_GATE, false },
    { SUSFS_L_LSM_HOOK, true },
    { SUSFS_L_SUS_PATH, true },
    { SUSFS_L_CREATE_GATE, false },
    { SUSFS_L_OPATH, false },
    { SUSFS_L_DIRENT, false },
    { SUSFS_L_UNAME, false },
    { SUSFS_L_KSTAT, false },
    { SUSFS_L_SUS_MAP, false },
    { SUSFS_L_SUS_MOUNT, false },
    { SUSFS_L_CMDLINE, false },
    { SUSFS_L_OPEN_REDIRECT, false },
    { SUSFS_L_ENABLE_LOG, false },
    { SUSFS_L_AVC_SPOOF, false },
    { SUSFS_L_SUPERCALL, true },
    { SUSFS_L_HIDE_SYMS, false },
};

static int susfs_load_layer(int id, bool fatal)
{
    struct susfs_layer *l;
    int ret;

    if (id < 0 || id >= SUSFS_L_COUNT) {
        susfs_layers_down(SUSFS_L_COUNT - 1);
        return -EINVAL;
    }
    l = &susfs_layers[id];

    /* Marked before the call: a layer that half-ran still has to be taken down. */
    l->armed = true;
    if (fail_layer == id + 1) {
        pr_warn("susfs_guard_lkm: fail_layer=%d - forcing %s's init to fail (diagnostic)\n",
                fail_layer, l->name);
        ret = -EIO;
    } else {
        ret = l->init ? l->init() : 0;
    }
    if (!ret) {
        if (l->feature >= 0)
            susfs_supercall_arm_feature(l->feature);
        return 0;
    }
    if (fatal) {
        pr_err("susfs_guard_lkm: %s init failed %d, refusing to load\n", l->name, ret);
        /* The kernel is about to free this module; a hook left behind points into it. */
        susfs_layers_down(SUSFS_L_COUNT - 1);
        return ret;
    }
    pr_warn("susfs_guard_lkm: %s init failed %d - that feature stays off\n", l->name, ret);
    return 0;
}

static int __init susfs_init(void)
{
    int i;

    /* First, before any layer runs and while nothing is armed: an import that was not filled in
     * is an address this module would jump to on its first call through it.  See
     * imports_guard.c - a loader that continues after an unresolved name leaves it zero, which
     * the kernel accepts without a word. */
    if (susfs_imports_guard())
        return -EINVAL;

    SUSFS_LOGI("init v%s\n", SUSFS_LKM_VERSION);

    if (ksu_init_symbol_resolver())
        return -ENODATA;

    /* Dead man's switch: refuse loading if in-built SuSFS is present */
    if (find_kernel_symbol_exact("susfs_is_inode_sus_path") ||
        find_kernel_symbol_exact("susfs_sus_kstat_spoof_generic_fillattr")) {
        pr_err("susfs_guard_lkm: in-built SuSFS is already active in kernel; refusing to load\n");
        return -EEXIST;
    }

    /* Now that kallsyms lookups work, check the addresses themselves: see imports_guard.c. */
    if (susfs_imports_crosscheck())
        return -EINVAL;

    /* Text/data patching needs a cache-flush helper whose name differs between kernels; resolve it
     * here, before any layer can patch.  Not fatal by itself, but below 6.12 sus_path is a fatal
     * layer and it installs its hooks by patching text, so a kernel carrying neither spelling ends
     * up refusing to load the module - with the reason in the log right here.  On 6.12+ that path
     * goes through static calls and this only costs the layers that do patch. */
    if (ksu_patch_memory_init())
        pr_warn("susfs_guard_lkm: patching unavailable on this kernel (see patch_memory.c)\n");

    /* One HooKern lifetime, before any layer: uname inline can arm from its own
     * init, not only from a later supercall.  Failure is not fatal. */
    if (susfs_hook_engine_init())
        pr_warn("susfs_guard_lkm: inline engine unavailable - consumers fall back\n");

    BUILD_BUG_ON(ARRAY_SIZE(susfs_layers) != SUSFS_L_COUNT);
    BUILD_BUG_ON(ARRAY_SIZE(susfs_load_plan) != SUSFS_L_COUNT);
    for (i = 0; i < (int)ARRAY_SIZE(susfs_load_plan); i++) {
        if (susfs_load_plan[i].id != i) {
            pr_err("susfs_guard_lkm: load plan entry %d names layer %d - refusing to load\n",
                   i, susfs_load_plan[i].id);
            return -EINVAL;
        }
    }

    for (i = 0; i < (int)ARRAY_SIZE(susfs_load_plan); i++) {
        int ret;

        ret = susfs_load_layer(susfs_load_plan[i].id, susfs_load_plan[i].fatal);
        if (ret) {
            susfs_layers_down(SUSFS_L_COUNT - 1);
            return ret;
        }
    }

    susfs_hook_map_report();

    /* Registered last and undone implicitly: these are entries in sus_path's table, which
     * sus_path_exit() empties while its LSM layer still answers ENOENT for the nodes. */
    susfs_self_hide_nodes();
    susfs_relabel_control_nodes();

    /* Operator note.  The module hides its own traces from EVERY caller, root included (a
     * built-in SUSFS has no module entry, so hiding it only from non-root would leave a
     * trace upstream does not have): `lsmod | grep susfs` stays empty and a second `insmod`
     * fails with -EEXIST, which reads like a broken module.
     * THE ONE LINE THAT IGNORES THE LOG SWITCH: everything else follows enable_log
     * (susfs_log.h), but this is the only evidence the module came up and the one thing an
     * operator greps for, so it stays unconditional even for a silent load - otherwise
     * "loaded but logging off" is indistinguishable from "not loaded".  The prefix comes
     * from pr_fmt (susfs_log.h), so the message must not repeat it. */
    pr_info("loaded. This module is filtered out of /proc/modules for every caller including root, so `lsmod | grep susfs` stays empty - check /sys/module/%s instead (a second insmod fails with -EEXIST while it is loaded).\n",
            SUSFS_LKM_MODULE_NAME);

    /* A fallback kprobe on __arm64_sys_reboot is a visible breakpoint, not just an
     * implementation detail.  Emit this after every layer has armed and only when the
     * module is actually loaded; keep it unconditional (pr_warn, not SUSFS_LOGI) so it
     * survives enable_log=0, like the loaded line above. */
    if (susfs_supercall_kprobe_active())
        pr_warn("supercall delivery fell back to the kprobe path: it leaves a breakpoint on __arm64_sys_reboot, visible through /sys/kernel/debug/kprobes/list and text/instruction inspection - treat this as a side channel.\n");

    return 0;
}

static void __exit susfs_exit(void)
{
    susfs_layers_down((int)ARRAY_SIZE(susfs_layers) - 1);
    susfs_hook_engine_exit();
    SUSFS_LOGI("susfs_guard_lkm: exit\n");
}

module_init(susfs_init);
module_exit(susfs_exit);
MODULE_LICENSE("GPL");

/* The VFS symbol namespace of this kernel's GKI builds.
 *
 * Four symbols this module imports - kern_path and ihold (fs/), override_creds and
 * revert_creds (kernel/cred.c) - are exported as
 * EXPORT_SYMBOL_NS(sym, ANDROID_GKI_VFS_EXPORT_ONLY), and the Android build maps that
 * name to the long string below with a per-directory ccflag before the compiler
 * stringifies it (fs/Makefile: subdir-ccflags-y += -DANDROID_GKI_VFS_EXPORT_ONLY=...,
 * plus kernel/Makefile for cred.o on some releases).  A module that does not import the
 * RESULTING string is refused by the kernel's module loader with
 *   "module uses symbol (kern_path) from namespace VFS_internal_... but does not import
 *    it"  ->  "Unknown symbol kern_path (err -22)"
 * which is why plain insmod failed on the phone before this line existed.
 *
 * The long form must be written out literally: MODULE_IMPORT_NS(ns) stringifies its
 * argument, so passing the macro name ANDROID_GKI_VFS_EXPORT_ONLY would import a
 * namespace that no kernel ever creates.  (Measured on the built .ko: .modinfo carried
 * no import_ns entry at all.)
 *
 * v6.13 turned that upside down: "module: Convert symbol namespace to string literal"
 * (upstream cdd30ebb1b9f, also in the Android common trees) made the macro's argument a
 * STRING LITERAL, so the old token form now stringifies into "\"VFS_...\"" and the import
 * is refused.  Both spellings are kept below and chosen by version, so the same source
 * builds from 5.10 through 6.18.
 *
 * Note this is necessary but NOT sufficient for plain insmod: further symbols we
 * reference are not in the kernel's export table in any of the six supported GKI
 * variants (kallsyms_lookup_name and friends, saved_boot_config, task_work_add, init_mm,
 * __set_fixmap, copy_to_kernel_nofault), so loading without a
 * helper still needs those to be resolved at runtime.  The userspace loader
 * (tools/susfs_insmod.c) sidesteps the whole question by rewriting undefined symbols to
 * absolute addresses, exactly as KernelSU's ksud does - see README. */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0)
MODULE_IMPORT_NS("VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver");
#else
MODULE_IMPORT_NS(VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver);
#endif
MODULE_DESCRIPTION("SUSFS guard LKM (susfs_guard_lkm) v2.3.0-gki");
