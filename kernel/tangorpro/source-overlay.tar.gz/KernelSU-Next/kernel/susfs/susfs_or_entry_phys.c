/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * susfs_or_entry_phys.c - open_redirect name-layer symbols (P layer)
 *
 * Every kernel function used by the name layer is held in a plain pointer and
 * called from a __nocfi noinline wrapper here, never from the entry itself.
 */

#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/types.h>

/* include/uapi/linux/openat2.h: three u64 fields, identical on both ABIs we build for. */
struct susfs_open_how {
	__u64 flags;
	__u64 mode;
	__u64 resolve;
};

#include "susfs_log.h"
#include "symbol_resolver.h"
#include "susfs_or_entry_data.h"
#include "susfs_or_entry_phys.h"
#include <linux/fcntl.h>	/* AT_FDCWD, O_CLOEXEC, __O_TMPFILE */
#include <linux/path.h>		/* path_put() */
#include <linux/namei.h>	/* getname_flags/filename_lookup, LOOKUP_* */
#include <linux/dcache.h>
#include <linux/mount.h>
#include <linux/err.h>
#include <linux/atomic.h>
#include <linux/limits.h>
#include <linux/uaccess.h>
#include "susfs_opath.h"
#include "susfs_open_redirect.h"
#include "susfs_open_data.h"
#include "susfs_open_view.h"
#include "susfs_or_entry.h"
#include "ksu_umount_gate.h"

/* Indirect call into the kernel for the one notification the skipped syscall
 * would have sent, so it sits in a __nocfi noinline function like every other
 * one in this module (tools/cfi_sites.py fails the build on an instrumented
 * call site).  A kernel without the symbol only loses the notification. */
__nocfi noinline void susfs_or_fsnotify_open(struct file *file)
{
	if (susfs_or_syms.fsnotify_open)
		susfs_or_syms.fsnotify_open(file);
}

/* Same shape for copy_struct_from_user()'s zero check: it is the helper
 * openat2 uses to accept a structure larger than this kernel's, and it is a
 * real exported symbol even though the macro that calls it is not. */
__nocfi noinline int susfs_or_check_zeroed_user(const void __user *from, unsigned long count)
{
	return susfs_or_syms.check_zeroed_user(from, count);
}

/* The undo of get_unused_fd_flags(): needed to keep the kernel's own order
 * (descriptor first, file second). */
__nocfi noinline void susfs_or_put_unused_fd(unsigned int fd)
{
	susfs_or_syms.put_unused_fd(fd);
}

int susfs_or_entry_symbols_resolve(void)
{
	susfs_or_syms.getname_flags = (void *)find_kernel_symbol_exact("getname_flags");
	susfs_or_syms.filename_lookup = (void *)find_kernel_symbol_exact("filename_lookup");
	susfs_or_syms.putname = (void *)find_kernel_symbol_exact("putname");
	susfs_or_syms.filp_open = (void *)find_kernel_symbol_exact("filp_open");
	susfs_or_syms.get_unused_fd_flags = (void *)find_kernel_symbol_exact("get_unused_fd_flags");
	susfs_or_syms.fd_install = (void *)find_kernel_symbol_exact("fd_install");
	susfs_or_syms.put_unused_fd = (void *)find_kernel_symbol_exact("put_unused_fd");
	/* Optional: only the inotify/fanotify notification depends on it. */
	susfs_or_syms.fsnotify_open = (void *)find_kernel_symbol_exact("fsnotify_open");
	if (!susfs_or_syms.fsnotify_open)
		SUSFS_LOGI("or_entry: fsnotify_open not found - a redirected open will not produce IN_OPEN\n");
	/* Optional too, and only for openat2 calls whose structure is larger than this kernel's. */
	susfs_or_syms.check_zeroed_user = (void *)find_kernel_symbol_exact("check_zeroed_user");
	if (!susfs_or_syms.check_zeroed_user)
		SUSFS_LOGI("or_entry: check_zeroed_user not found - openat2 with a larger open_how is not redirected\n");

	if (!susfs_or_syms.getname_flags || !susfs_or_syms.filename_lookup ||
	    !susfs_or_syms.putname || !susfs_or_syms.filp_open ||
	    !susfs_or_syms.get_unused_fd_flags || !susfs_or_syms.fd_install ||
	    !susfs_or_syms.put_unused_fd) {
		SUSFS_LOGI("or_entry: not armed, a symbol is missing (getname_flags=%d filename_lookup=%d putname=%d filp_open=%d get_unused_fd_flags=%d fd_install=%d put_unused_fd=%d) - open_redirect will refuse rules\n",
			   !!susfs_or_syms.getname_flags, !!susfs_or_syms.filename_lookup,
			   !!susfs_or_syms.putname, !!susfs_or_syms.filp_open,
			   !!susfs_or_syms.get_unused_fd_flags, !!susfs_or_syms.fd_install,
			   !!susfs_or_syms.put_unused_fd);
		return 1;
	}
	return 0;
}

/* The flag set the kernel's own build_open_flags() accepts (fs/open.c VALID_OPEN_FLAGS, which is
 * built from exactly these uapi bits).  A flag outside it makes the kernel return EINVAL, so such a
 * call is handed back rather than answered: filp_open() masks unknown bits away and would turn that
 * EINVAL into a successful open.  This is deliberately the conservative direction - a bit that is
 * legal on some kernel but missing here only means that open is not redirected. */
#define SUSFS_OR_KNOWN_FLAGS							\
	(O_RDONLY | O_WRONLY | O_RDWR | O_CREAT | O_EXCL | O_NOCTTY | O_TRUNC |	\
	 O_APPEND | O_NONBLOCK | O_NDELAY | __O_SYNC | O_DSYNC | FASYNC |	\
	 O_DIRECT | O_LARGEFILE | O_DIRECTORY | O_NOFOLLOW | O_NOATIME |		\
	 O_CLOEXEC | O_PATH | __O_TMPFILE)

/* fs/open.c's own O_PATH_FLAGS, and what build_open_how() narrows the flags to whenever O_PATH is
 * present ("O_PATH beats everything else.").  Only these four bits survive that narrowing, so
 * everything a caller sends alongside O_PATH - O_CREAT, O_EXCL, O_TRUNC - is gone before the kernel
 * works out the lookup flags of the call.  It lives as a #define inside fs/open.c rather than in a
 * header, hence spelled out here; O_CLOEXEC being in the set is also why a descriptor's own flag
 * survives the narrowing. */
#define SUSFS_OR_PATH_FLAGS	(O_DIRECTORY | O_NOFOLLOW | O_PATH | O_CLOEXEC)

/* openat2's resolve bits (uapi/linux/openat2.h) and the lookup flags the kernel turns them into. */
#define SUSFS_RESOLVE_NO_XDEV		0x01
#define SUSFS_RESOLVE_NO_MAGICLINKS	0x02
#define SUSFS_RESOLVE_NO_SYMLINKS	0x04
#define SUSFS_RESOLVE_BENEATH		0x08
#define SUSFS_RESOLVE_IN_ROOT		0x10
#define SUSFS_RESOLVE_CACHED		0x20
#define SUSFS_OR_KNOWN_RESOLVE							\
	(SUSFS_RESOLVE_NO_XDEV | SUSFS_RESOLVE_NO_MAGICLINKS |			\
	 SUSFS_RESOLVE_NO_SYMLINKS | SUSFS_RESOLVE_BENEATH |			\
	 SUSFS_RESOLVE_IN_ROOT | SUSFS_RESOLVE_CACHED)

/* The lookup flags for the source path, translated the way the kernel translates them for the open
 * it would have done (fs/open.c, before do_filp_open): O_NOFOLLOW stops at the last component and
 * O_CREAT|O_EXCL implies it, O_DIRECTORY demands a directory, and openat2's resolve bits map onto
 * the matching LOOKUP_* bits.  A resolve bit this kernel has no lookup flag for (LOOKUP_CACHED
 * arrived later than the others) is not mapped - the caller then gets a lookup with weaker
 * semantics, which is why susfs_or_entry_redirect() rejects those calls instead of answering them. */
static unsigned int or_lookup_flags(unsigned long flags, unsigned long resolve)
{
	unsigned int lflags = 0;

	if (!(flags & O_NOFOLLOW) &&
	    (flags & (O_CREAT | O_EXCL)) != (O_CREAT | O_EXCL))
		lflags |= LOOKUP_FOLLOW;
	if (flags & O_DIRECTORY)
		lflags |= LOOKUP_DIRECTORY;
	if (resolve & SUSFS_RESOLVE_NO_XDEV)
		lflags |= LOOKUP_NO_XDEV;
	if (resolve & SUSFS_RESOLVE_NO_MAGICLINKS)
		lflags |= LOOKUP_NO_MAGICLINKS;
	if (resolve & SUSFS_RESOLVE_NO_SYMLINKS)
		lflags |= LOOKUP_NO_SYMLINKS;
	if (resolve & SUSFS_RESOLVE_BENEATH)
		lflags |= LOOKUP_BENEATH;
	if (resolve & SUSFS_RESOLVE_IN_ROOT)
		lflags |= LOOKUP_IN_ROOT;
#ifdef LOOKUP_CACHED
	if (resolve & SUSFS_RESOLVE_CACHED)
		lflags |= LOOKUP_CACHED;
#endif
	return lflags;
}

__nocfi noinline long susfs_or_entry_redirect(const struct pt_regs *regs, int kind)
{
	const char __user *uname = NULL;
	unsigned long flags = 0, mode = 0, resolve = 0, usize = 0, o2flags = 0;
	/* The descriptor's own flag, kept out of the narrowing the file flags go through: the kernel
	 * takes it from the UNSTRIPPED flags when it allocates a descriptor (do_sys_openat2():
	 * get_unused_fd_flags(how->flags), where alloc_fd() reads O_CLOEXEC), and losing it hands back a fd that survives
	 * execve - a difference one fcntl(F_GETFD) reads. */
	unsigned int fd_cloexec = 0;
	struct susfs_open_how how;
	struct filename *name;
	struct path path;
	char target[SUSFS_OR_PATH_MAX];	/* filled by susfs_open_rule_facts_path() under rcu */
	struct susfs_open_view ov;
	struct susfs_open_rule_facts rf;
	struct file *f;
	int dfd = AT_FDCWD;
	long res;
	int fd;

	if (!susfs_or_entry_ready)
		return SUSFS_OR_ENTRY_PASS;

	/* This hook is reached for every open() on the system, so the empty case has to be one load: no
	 * live rules means nothing to resolve a name for, and deleting the last rule takes that cost away
	 * again (susfs_open_redirect_rules counts live rules, not rules ever added). */
	if (!susfs_open_redirect_active())
		return SUSFS_OR_ENTRY_PASS;

	/* arm64 keeps a syscall's arguments in regs[0..5] for native and compat alike, so the
	 * argument number IS the register index (arch/arm64/include/asm/syscall_wrapper.h). */
	switch (kind) {
	case SUSFS_OR_ENTRY_OPENAT:
	case SUSFS_OR_ENTRY_COMPAT_OPENAT:
		dfd = (int)regs->regs[0];
		uname = (const char __user *)regs->regs[1];
		/* Truncated to what the kernel's own declaration is: these entries take an `int flags`
		 * and the syscall wrapper casts the register to it (__SC_CAST), so the upper half of the
		 * register is ignored by the kernel.  Keeping it here would make the unknown-bit test
		 * below see a "flag the kernel would reject" and hand a call the kernel resolves as a
		 * plain open straight back to it - i.e. the redirect would be bypassable with
		 * `flags | (1UL << 32)`.  openat2 is the exception and stays 64-bit, because the kernel
		 * does not mask how.flags. */
		flags = (unsigned int)regs->regs[2];
		mode = regs->regs[3];
		break;
	case SUSFS_OR_ENTRY_COMPAT_OPEN:
		/* COMPAT_SYSCALL_DEFINE3: no dirfd, so the arguments shift down by one. */
		uname = (const char __user *)regs->regs[0];
		flags = (unsigned int)regs->regs[1];
		mode = regs->regs[2];
		break;
	case SUSFS_OR_ENTRY_OPENAT2:
	case SUSFS_OR_ENTRY_COMPAT_OPENAT2:
		dfd = (int)regs->regs[0];
		uname = (const char __user *)regs->regs[1];
		usize = regs->regs[3];
		/* The kernel's own rules for this structure: a size below it is EINVAL, a size above it
		 * is accepted as long as the bytes this kernel does not know are zero (that is what
		 * copy_struct_from_user() checks, through check_zeroed_user()), and anything else is
		 * E2BIG.  A call that gets here and is then not redirected still opens the real file, so
		 * "we cannot be bothered" is not an option for a size the kernel would have accepted:
		 * those go through when the helper is resolvable, and only fall back to the kernel where
		 * it is not. */
		if (usize < sizeof(how))
			return SUSFS_OR_ENTRY_PASS;
		if (copy_from_user(&how, (const void __user *)regs->regs[2], sizeof(how)))
			return SUSFS_OR_ENTRY_PASS;
		if (usize > sizeof(how) &&
		    (!susfs_or_syms.check_zeroed_user ||
		     susfs_or_check_zeroed_user((const void __user *)regs->regs[2] + sizeof(how),
					  usize - sizeof(how)) <= 0))
			return SUSFS_OR_ENTRY_PASS;
		/* ... and the two bits the kernel removes from these flags before it looks at any of them
		 * (FMODE_NONOTIFY, which the caller is not supposed to see, and O_CLOEXEC, which belongs
		 * to the descriptor).  Everything below is judged on what is left, exactly like the
		 * kernel does: FMODE_NONOTIFY is not one of O_PATH_FLAGS, so judging the raw flags would
		 * turn a legal `O_PATH|FMODE_NONOTIFY` open into "a flag the kernel would refuse" and hand
		 * the call back to a kernel that opens the real file. */
		/* O_CLOEXEC is stripped from the copy everything below judges, because it is not a
		 * property of the file - but it belongs to the DESCRIPTOR, and the kernel keeps it for
		 * exactly the moment it allocates one: do_sys_openat2() calls
		 * get_unused_fd_flags(how->flags), where alloc_fd() reads O_CLOEXEC.  Dropping it here
		 * (this branch assigns flags = o2flags a few lines down, and that copy is what the
		 * descriptor was allocated from) gave every redirected openat2(..., O_CLOEXEC) a fd
		 * without FD_CLOEXEC: it survives execve, and fcntl(F_GETFD) says so in one call. */
		fd_cloexec = (unsigned int)(how.flags & O_CLOEXEC);
		o2flags = how.flags & ~(unsigned long)(FMODE_NONOTIFY | O_CLOEXEC);
		/* A resolve bit the kernel does not know is EINVAL, and EINVAL is an answer we cannot
		 * give: it comes from the kernel.  A bit it does know is mapped onto the same LOOKUP_*
		 * flags it would use (see or_lookup_flags()), so the caller's resolve semantics still
		 * hold for the path this layer looks up itself. */
		if (how.resolve & ~SUSFS_OR_KNOWN_RESOLVE)
			return SUSFS_OR_ENTRY_PASS;
		/* The two combinations the kernel refuses before it looks at anything: RESOLVE_BENEATH
		 * together with RESOLVE_IN_ROOT is EINVAL, and RESOLVE_CACHED with a call that would
		 * create or truncate is EAGAIN (it will not fall back to a normal lookup).  Both are
		 * answered by the kernel rather than by us - the second one is not just a difference in
		 * the answer, it is a rule target that would be created or truncated.  The mask is the
		 * kernel's own spelling, which is EAGAIN for a plain O_DIRECTORY too. */
		if ((how.resolve & SUSFS_RESOLVE_BENEATH) && (how.resolve & SUSFS_RESOLVE_IN_ROOT))
			return SUSFS_OR_ENTRY_PASS;
		if ((how.resolve & SUSFS_RESOLVE_CACHED) &&
		    (o2flags & (O_TRUNC | O_CREAT | O_TMPFILE)))
			return SUSFS_OR_ENTRY_PASS;
#ifndef LOOKUP_CACHED
		/* This kernel cannot honour RESOLVE_CACHED, and answering the call with a normal lookup
		 * would succeed where the kernel answers EAGAIN (it refuses to touch the disk for it). */
		if (how.resolve & SUSFS_RESOLVE_CACHED)
			return SUSFS_OR_ENTRY_PASS;
#endif
		resolve = how.resolve;
		/* openat2 validates every field of the structure, where the older syscalls silently
		 * clean invalid values up (build_open_flags(): mode & ~S_IALLUGO is EINVAL when the
		 * call creates something, non-zero mode otherwise, and filp_open() would strip both
		 * before the kernel could object).  Answering such a call with a successful open is the
		 * one outcome we must not produce, so it goes back too. */
		if ((o2flags & (O_CREAT | __O_TMPFILE)) ? (how.mode & ~S_IALLUGO) : how.mode)
			return SUSFS_OR_ENTRY_PASS;
		/* openat2 does not pass through build_open_how(), so the kernel tests its O_PATH rule
		 * against these same stripped flags: anything besides O_PATH_FLAGS is EINVAL there, while
		 * filp_open() would quietly mask those bits away and open the file. */
		if ((o2flags & O_PATH) &&
		    (o2flags & ~(unsigned long)(O_DIRECTORY | O_NOFOLLOW | O_PATH | O_CLOEXEC)))
			return SUSFS_OR_ENTRY_PASS;
		flags = o2flags;
		mode = how.mode;
		break;
	default:
		return SUSFS_OR_ENTRY_PASS;
	}

	/* The flags are handled the way the kernel handles them per entry, because that
	 * differs: openat2 validates every field and answers EINVAL for a flag it does not know
	 * (fs/open.c: build_open_flags() tests the raw how.flags), while open/openat/compat clean the
	 * invalid bits away first (build_open_how(): `flags & VALID_OPEN_FLAGS`) and then open the file
	 * as if they had not been passed.  Treating an unknown bit as "the kernel will refuse this" on
	 * the older entries would hand the call back to a kernel that happily opens the real file - a
	 * one-bit bypass of the redirect, and a cheaper one than any of the above.  So the older entries
	 * get the same mask the kernel applies, and only openat2 can be declined over a flag. */
	if (kind == SUSFS_OR_ENTRY_OPENAT2 || kind == SUSFS_OR_ENTRY_COMPAT_OPENAT2) {
		/* Those two bits were already removed in the branch above, before its first check - the
		 * kernel removes them before any of its own.  What is left is the gate the kernel applies
		 * to these flags (build_open_flags(): `flags & ~VALID_OPEN_FLAGS` is EINVAL). */
		if (flags & ~SUSFS_OR_KNOWN_FLAGS)
			return SUSFS_OR_ENTRY_PASS;
	} else {
		flags &= SUSFS_OR_KNOWN_FLAGS;
		/* The kernel narrows O_PATH before anything else looks at the flags - "O_PATH beats
		 * everything else." in build_open_how() - so by the time build_open_flags() works out
		 * whether the last component is followed, an O_CREAT/O_EXCL that arrived alongside
		 * O_PATH is already gone.  Judging the flags as they arrived made this layer resolve a
		 * DIFFERENT name than the kernel resolves: it saw O_CREAT|O_EXCL, withheld
		 * LOOKUP_FOLLOW, and matched the rule table against the symlink itself, while the
		 * kernel followed that symlink and opened its target.  So a caller who writes
		 * `ln -s <rule target> <a path of his own>` and then asks for O_PATH|O_CREAT|O_EXCL
		 * was handed the un-redirected file - the redirect stepped around without ever touching
		 * the rule table.  Narrowed here, both layers walk the same name.
		 *
		 * (openat2 does not narrow: it never calls build_open_how(), and build_open_flags()
		 * answers that same combination with EINVAL - which is why the branch above is left
		 * alone.) */
		if (flags & O_PATH)
			flags &= SUSFS_OR_PATH_FLAGS;
		/* From the same function: a call that cannot create carries no mode, and an O_PATH
		 * open never can. */
		if (flags & O_PATH)
			mode = 0;
		/* O_CLOEXEC survives the narrowing above (it is one of O_PATH_FLAGS), so the
		 * descriptor's flag is read from the flags the kernel would allocate it from. */
		fd_cloexec = (unsigned int)(flags & O_CLOEXEC);
	}

	memset(&ov, 0, sizeof(ov));
	ov.kind = (enum susfs_open_kind)kind;
	ov.flags = flags;
	ov.resolve = resolve;
	ov.mode = (unsigned int)mode;
	ov.valid = true;
	ov.mode_valid = true;
	ov.resolve_supported = true;
	if ((kind == SUSFS_OR_ENTRY_OPENAT2 ||
	     kind == SUSFS_OR_ENTRY_COMPAT_OPENAT2) &&
	    ((flags & (O_CREAT | __O_TMPFILE)) ?
	     (mode & ~S_IALLUGO) : mode))
		ov.mode_valid = false;
#ifndef LOOKUP_CACHED
	if (resolve & SUSFS_OPEN_RESOLVE_CACHED)
		ov.resolve_supported = false;
#endif
	if (susfs_open_decide_core(&ov) == SUSFS_OPEN_PASS)
		return SUSFS_OR_ENTRY_PASS;

	/* Which inode is the caller opening?  The lookup flags are the kernel's own translation of the
	 * caller's flags and of openat2's resolve bits (fs/open.c, right before do_filp_open): with
	 * LOOKUP_FOLLOW hard-wired, a caller's O_NOFOLLOW turned its ELOOP into a successful redirect -
	 * a difference from a kernel without this module, and one that also tells an observer which
	 * paths carry a rule (write a symlink to the path and open it with O_NOFOLLOW).  A path that
	 * does not resolve (O_CREAT of a new file) cannot be the target of a rule, so the kernel is
	 * left to answer it. */
	name = susfs_or_syms.getname_flags(uname, 0, NULL);
	if (IS_ERR(name))
		return SUSFS_OR_ENTRY_PASS;
	res = susfs_or_syms.filename_lookup(dfd, name, or_lookup_flags(flags, resolve), &path, NULL);
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 15, 0)
	/* filename_lookup() consumed `name` through 5.14; 5.15 made the caller own it.
	 * Putting it here again double-frees and panics (the create_gate 5.10 KE). */
#else
	susfs_or_syms.putname(name);
#endif
	if (res)
		return SUSFS_OR_ENTRY_PASS;

	/* The target name is copied out of the rule while the lookup holds rcu_read_lock (rule slots are
	 * recycled after a grace period, so nothing inside an entry may be used after this call). */
	susfs_open_rule_facts_path(&path, &rf);
	if (!rf.matched) {
		path_put(&path);
		return SUSFS_OR_ENTRY_PASS;
	}
	path_put(&path);	/* no reference is kept anywhere: the rule owns none either */

	ov.rule_matched = true;
	ov.uid_scheme = rf.uid_scheme;
	strscpy(ov.redirected, rf.redirected, sizeof(ov.redirected));
	ov.caller_uid = current_uid().val;
	ov.caller_in_su_domain = susfs_open_redirect_in_su_domain();
	ov.caller_is_umounted_app = susfs_is_current_proc_umounted_app();
	ov.caller_is_umounted = susfs_is_current_proc_umounted();
	if (susfs_open_decide_core(&ov) == SUSFS_OPEN_PASS)
		return SUSFS_OR_ENTRY_PASS;
	strscpy(target, ov.redirected, sizeof(target));

	/* Defensive: an empty name is not a path, and filp_open("") resolves to the caller's own
	 * working directory, i.e. it would hand out an unrelated fd. */
	if (!target[0])
		return SUSFS_OR_ENTRY_PASS;

	/* arm64 always opens with O_LARGEFILE (force_o_largefile() is `!IS_ENABLED(CONFIG_ARCH_32BIT_OFF_T)`,
	 * and the syscall adds it before anything else looks at the flags).  Without it the fd we hand
	 * back differs from every other fd in one visible bit: fcntl(F_GETFL) and the `flags:` line of
	 * /proc/self/fdinfo/N both read f_flags directly.  CLOEXEC is the fd table's business, not the
	 * open's - the kernel strips it before build_open_flags() sees it - so it is masked off here.
	 *
	 * The compat entries are the exception: the kernel deliberately does not set the bit there
	 * ("Exactly like sys_openat(), except that it doesn't set the O_LARGEFILE flag"), and compat
	 * openat2 does, because it is the same implementation as the native one.  An O_PATH open does
	 * not carry it either - build_open_how() masks O_PATH opens to O_PATH_FLAGS. */
#ifdef __aarch64__
	if (!(flags & O_PATH) &&
	    kind != SUSFS_OR_ENTRY_COMPAT_OPEN && kind != SUSFS_OR_ENTRY_COMPAT_OPENAT)
		flags |= O_LARGEFILE;
#endif
	/* The descriptor is taken BEFORE the file is opened, which is the order do_sys_openat2() uses:
	 * an EMFILE/ENFILE open then touches nothing at all, where opening first would have created or
	 * truncated the rule's target and then failed anyway. */
	fd = susfs_or_syms.get_unused_fd_flags(fd_cloexec);
	if (fd < 0)
		return fd;

	f = susfs_or_syms.filp_open(target, (int)(flags & ~O_CLOEXEC), (umode_t)mode);
	if (IS_ERR(f)) {
		susfs_or_put_unused_fd((unsigned)fd);
		return PTR_ERR(f);
	}

	/* Same order as do_sys_openat2(): the notification goes out before the fd is visible.
	 *
	 * Only where the kernel does not send it itself.  On 5.10..6.1 the one fsnotify_open() call
	 * sits in do_sys_openat2(), which a filp_open() never reaches - without this line the
	 * redirected open would be the only open on the system with no IN_OPEN, which breaks inotify
	 * users and makes the redirect stand out.  6.6 moved that call into do_dentry_open()
	 * (fs/open.c:985 there) and 6.12 split it out again into vfs_open() (:1095); filp_open() goes
	 * through both, so on 6.6 and later the kernel has already reported this open and a second
	 * call here produced two IN_OPEN events for one open. */
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 6, 0)
	susfs_or_fsnotify_open(f);
#endif
	susfs_or_syms.fd_install((unsigned)fd, f);

	atomic_inc(&susfs_or_entry_hits);
	return fd;
}
